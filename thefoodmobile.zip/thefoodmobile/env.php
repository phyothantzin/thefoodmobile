<?php
$_ENV['DB_HOST'] = 'localhost:3307';
$_ENV['DB_USER'] = 'sol';
$_ENV['DB_PWD'] = 'soul@123';
$_ENV['DB_NAME'] = 'ojt2022_thefoodmobile';
